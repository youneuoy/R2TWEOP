#pragma once
namespace r2tweopManager
{
	void init();
};

