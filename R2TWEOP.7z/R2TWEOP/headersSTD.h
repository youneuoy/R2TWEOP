#pragma once
#include <windows.h>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>
#include <map>
#include <memory>
#include <algorithm>
#include <stdlib.h>





