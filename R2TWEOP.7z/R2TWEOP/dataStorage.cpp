#include "dataStorage.h"
dataStorage::globalDataT dataStorage::globalData;